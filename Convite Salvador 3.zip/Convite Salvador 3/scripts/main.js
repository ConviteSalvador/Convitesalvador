document.addEventListener('DOMContentLoaded', function() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    updateCartCount();

    if (window.location.pathname.endsWith('index.html') || window.location.pathname === '/') {
        loadProducts();
    } else if (window.location.pathname.endsWith('cart.html')) {
        loadCartItems();
        setupCheckoutForm();
    }
});

function loadProducts() {
    fetch('data/products.json')
        .then(response => response.json())
        .then(products => {
            const productList = document.getElementById('product-list');
            products.forEach(product => {
                const productCard = `
                    <div class="col-md-4">
                        <div class="card">
                            <img src="${product.images[0]}" class="card-img-top" alt="${product.name}">
                            <div class="card-body">
                                <h5 class="card-title">${product.name}</h5>
                                <p class="card-text">${product.price}</p>
                                <button onclick="viewProduct(${product.id})" class="btn btn-primary">Ver Produto</button>
                            </div>
                        </div>
                    </div>
                `;
                productList.innerHTML += productCard;
            });
        });
}

function viewProduct(productId) {
    fetch('data/products.json')
        .then(response => response.json())
        .then(products => {
            const product = products.find(p => p.id === productId);
            if (product) {
                // Preenche o modal com os dados do produto
                document.getElementById('modalProductName').textContent = product.name;
                document.getElementById('modalProductDescription').textContent = product.description;
                document.getElementById('modalProductPrice').textContent = `Preço: ${product.price}`;

                // Preenche o carousel de imagens
                const carouselInner = document.getElementById('carousel-inner');
                carouselInner.innerHTML = '';
                product.images.forEach((image, index) => {
                    const carouselItem = document.createElement('div');
                    carouselItem.classList.add('carousel-item');
                    if (index === 0) carouselItem.classList.add('active');
                    carouselItem.innerHTML = `<img src="${image}" class="d-block w-100" alt="${product.name}">`;
                    carouselInner.appendChild(carouselItem);
                });

                // Preenche as opções de envelope
                const envelopeOptions = document.getElementById('envelopeOptions');
                envelopeOptions.innerHTML = '';
                product.envelopeOptions.forEach(option => {
                    const button = document.createElement('button');
                    button.type = 'button';
                    button.classList.add('btn', 'btn-outline-secondary', 'me-2');
                    button.textContent = option;
                    button.onclick = () => selectOption('envelope', option);
                    envelopeOptions.appendChild(button);
                });

                // Preenche as opções de encarte
                const insertOptions = document.getElementById('insertOptions');
                insertOptions.innerHTML = '';
                product.insertOptions.forEach(option => {
                    const button = document.createElement('button');
                    button.type = 'button';
                    button.classList.add('btn', 'btn-outline-secondary', 'me-2');
                    button.textContent = option;
                    button.onclick = () => selectOption('insert', option);
                    insertOptions.appendChild(button);
                });

                // Reseta a quantidade
                document.getElementById('quantity').value = 1;

                // Exibe o modal
                const productModal = new bootstrap.Modal(document.getElementById('productModal'));
                productModal.show();
            }
        });
}

let selectedEnvelope = '';
let selectedInsert = '';

function selectOption(type, option) {
    const envelopeOptions = document.querySelectorAll('#envelopeOptions .btn');
    const insertOptions = document.querySelectorAll('#insertOptions .btn');

    if (type === 'envelope') {
        // Remove a classe 'active' de todas as opções de envelope
        envelopeOptions.forEach(btn => btn.classList.remove('btn-primary', 'btn-secondary'));
        // Adiciona a classe 'active' à opção selecionada
        const selectedButton = Array.from(envelopeOptions).find(btn => btn.textContent === option);
        selectedButton.classList.add('btn-primary');
        selectedEnvelope = option;
    } else if (type === 'insert') {
        // Remove a classe 'active' de todas as opções de encarte
        insertOptions.forEach(btn => btn.classList.remove('btn-primary', 'btn-secondary'));
        // Adiciona a classe 'active' à opção selecionada
        const selectedButton = Array.from(insertOptions).find(btn => btn.textContent === option);
        selectedButton.classList.add('btn-primary');
        selectedInsert = option;
    }
}

function changeQuantity(amount) {
    const quantityInput = document.getElementById('quantity');
    let quantity = parseInt(quantityInput.value);
    quantity += amount;
    if (quantity < 1) quantity = 1;
    quantityInput.value = quantity;
}

function addToCartFromModal() {
    const productName = document.getElementById('modalProductName').textContent;
    const productPrice = document.getElementById('modalProductPrice').textContent.replace('Preço: ', '');
    const quantity = parseInt(document.getElementById('quantity').value);
    const product = { name: productName, price: productPrice, quantity, envelopeType: selectedEnvelope, insertType: selectedInsert };
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart.push(product);
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();

    // Fecha o modal
    const productModal = bootstrap.Modal.getInstance(document.getElementById('productModal'));
    productModal.hide();
}

function updateCartCount() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const cartCountElement = document.getElementById('cart-count');
    if (cartCountElement) {
        cartCountElement.textContent = cart.length;
    }
}

function loadCartItems() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const cartItems = document.getElementById('cart-items');
    cartItems.innerHTML = '';

    if (cart.length === 0) {
        cartItems.innerHTML = '<p>Nenhum item no carrinho.</p>';
        updateOrderSummary(cart);
        return;
    }

    cart.forEach((item, index) => {
        // Verifica se o item tem todas as propriedades necessárias
        if (!item.name || !item.price || !item.quantity || !item.envelopeType || !item.insertType) {
            console.error('Item do carrinho inválido:', item);
            return;
        }

        const cartItem = `
            <div class="card mb-3">
                <div class="card-body">
                    <h5 class="card-title">${item.name}</h5>
                    <p class="card-text">Envelope: ${item.envelopeType}</p>
                    <p class="card-text">Encarte: ${item.insertType}</p>
                    <p class="card-text">Preço Unitário: ${item.price}</p>
                    <div class="d-flex align-items-center">
                        <button class="btn btn-outline-secondary btn-sm" onclick="updateQuantity(${index}, -1)">-</button>
                        <input type="text" class="form-control text-center mx-2" style="width: 50px;" value="${item.quantity}" readonly>
                        <button class="btn btn-outline-secondary btn-sm" onclick="updateQuantity(${index}, 1)">+</button>
                        <button class="btn btn-link text-danger ms-auto" onclick="removeFromCart(${index})">
                            <i class="bi bi-trash"></i>
                        </button>
                    </div>
                    <p class="card-text mt-2">Subtotal: R$ ${(item.quantity * parseFloat(item.price.replace('R$ ', '').replace(',', '.'))).toFixed(2).replace('.', ',')}</p>
                </div>
            </div>
        `;
        cartItems.innerHTML += cartItem;
    });

    updateOrderSummary(cart);
}

function updateQuantity(index, amount) {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    if (cart[index]) {
        cart[index].quantity += amount;
        if (cart[index].quantity < 1) cart[index].quantity = 1; // Garante que a quantidade não seja menor que 1
        localStorage.setItem('cart', JSON.stringify(cart));
        loadCartItems();
        updateCartCount();
    }
}

function updateOrderSummary(cart) {
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    const totalPrice = cart.reduce((sum, item) => {
        if (!item.price) return sum; // Ignora itens sem preço
        const price = parseFloat(item.price.replace('R$ ', '').replace(',', '.'));
        return sum + (item.quantity * price);
    }, 0);

    document.getElementById('total-items').textContent = totalItems;
    document.getElementById('total-price').textContent = `R$ ${totalPrice.toFixed(2).replace('.', ',')}`;
}

function removeFromCart(index) {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart.splice(index, 1);
    localStorage.setItem('cart', JSON.stringify(cart));
    loadCartItems();
    updateCartCount();
}

function setupCheckoutForm() {
    const form = document.getElementById('checkout-form');
    form.addEventListener('submit', function(event) {
        event.preventDefault();
        const name = document.getElementById('name').value;
        const phone = document.getElementById('phone').value;
        const email = document.getElementById('email').value;
        const cart = JSON.parse(localStorage.getItem('cart')) || [];

        const message = `Pedido de ${name} (${email}, ${phone}):\n` +
            cart.map(item => `Produto: ${item.name}, Quantidade: ${item.quantity}, Envelope: ${item.envelopeType}, Encarte: ${item.insertType}, Subtotal: R$ ${(item.quantity * parseFloat(item.price.replace('R$ ', '').replace(',', '.'))).toFixed(2).replace('.', ',')}`).join('\n') +
            `\nTotal: R$ ${cart.reduce((sum, item) => sum + (item.quantity * parseFloat(item.price.replace('R$ ', '').replace(',', '.'))), 0).toFixed(2).replace('.', ',')}`;

        const whatsappUrl = `https://wa.me/SEU_NUMERO_AQUI?text=${encodeURIComponent(message)}`;
        window.open(whatsappUrl, '_blank');
    });
}